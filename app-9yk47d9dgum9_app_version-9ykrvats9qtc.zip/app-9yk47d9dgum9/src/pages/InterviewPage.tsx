import React, { useState } from 'react';
import { AnimatedBackground } from '@/components/AnimatedBackground';
import { WelcomeScreen } from '@/components/WelcomeScreen';
import { InterviewFlow } from '@/components/InterviewFlow';
import { SummaryScreen } from '@/components/SummaryScreen';
import type { InterviewStage, Question } from '@/types/index';

const InterviewPage: React.FC = () => {
  const [stage, setStage] = useState<InterviewStage>('welcome');
  const [jobRole, setJobRole] = useState('');
  const [completedQuestions, setCompletedQuestions] = useState<Question[]>([]);

  const handleStart = (role: string) => {
    setJobRole(role);
    setStage('interview');
  };

  const handleComplete = (questions: Question[]) => {
    setCompletedQuestions(questions);
    setStage('summary');
  };

  const handleRestart = () => {
    setJobRole('');
    setCompletedQuestions([]);
    setStage('welcome');
  };

  return (
    <>
      <AnimatedBackground />
      {stage === 'welcome' && <WelcomeScreen onStart={handleStart} />}
      {stage === 'interview' && <InterviewFlow jobRole={jobRole} onComplete={handleComplete} />}
      {stage === 'summary' && (
        <SummaryScreen jobRole={jobRole} questions={completedQuestions} onRestart={handleRestart} />
      )}
    </>
  );
};

export default InterviewPage;
