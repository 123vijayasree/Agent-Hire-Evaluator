// Type definitions for Agent Hire Evaluators

export interface Question {
  id: number;
  text: string;
  answer?: string;
  evaluation?: Evaluation;
}

export interface Evaluation {
  feedback: string;
  confidenceScore: number;
  improvementTip: string;
}

export interface FinalSummary {
  overallFeedback: string;
  finalConfidenceScore: number;
  topImprovementTip: string;
}

export interface InterviewState {
  jobRole: string;
  currentQuestionIndex: number;
  questions: Question[];
  isLoading: boolean;
  isComplete: boolean;
  finalSummary?: FinalSummary;
}

export type InterviewStage = 'welcome' | 'interview' | 'summary';
