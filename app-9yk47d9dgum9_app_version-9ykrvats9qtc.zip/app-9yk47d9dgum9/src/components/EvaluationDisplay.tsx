import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import type { Evaluation } from '@/types/index';

interface EvaluationDisplayProps {
  evaluation: Evaluation;
}

export const EvaluationDisplay: React.FC<EvaluationDisplayProps> = ({ evaluation }) => {
  const getScoreColor = (score: number) => {
    if (score >= 8) return 'bg-primary text-primary-foreground';
    if (score >= 6) return 'bg-secondary text-secondary-foreground';
    return 'bg-destructive text-destructive-foreground';
  };

  return (
    <Card className="glass border-primary/30 animate-slide-up">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="text-primary">Evaluation</span>
          <Badge className={`${getScoreColor(evaluation.confidenceScore)} text-lg px-4 py-1`}>
            {evaluation.confidenceScore}/10
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <h4 className="font-semibold text-foreground mb-2">Feedback:</h4>
          <p className="text-muted-foreground leading-relaxed">{evaluation.feedback}</p>
        </div>
        <div>
          <h4 className="font-semibold text-foreground mb-2">💡 Improvement Tip:</h4>
          <p className="text-muted-foreground leading-relaxed">{evaluation.improvementTip}</p>
        </div>
      </CardContent>
    </Card>
  );
};
