import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Loader2 } from 'lucide-react';
import { VoiceInput } from './VoiceInput';
import { EvaluationDisplay } from './EvaluationDisplay';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import type { Question, Evaluation } from '@/types/index';

interface InterviewFlowProps {
  jobRole: string;
  onComplete: (questions: Question[]) => void;
}

export const InterviewFlow: React.FC<InterviewFlowProps> = ({ jobRole, onComplete }) => {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answer, setAnswer] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isGeneratingQuestions, setIsGeneratingQuestions] = useState(true);
  const [showEvaluation, setShowEvaluation] = useState(false);

  useEffect(() => {
    generateQuestions();
  }, []);

  const generateQuestions = async () => {
    try {
      setIsGeneratingQuestions(true);
      
      console.log('Calling Edge Function with jobRole:', jobRole);
      
      const { data, error } = await supabase.functions.invoke('generate-interview-content', {
        body: {
          action: 'generate_questions',
          jobRole,
        },
      });

      if (error) {
        let errorMsg = 'Failed to connect to AI service';
        try {
          const errorText = await error?.context?.text();
          if (errorText) {
            const errorData = JSON.parse(errorText);
            errorMsg = errorData.error || errorText;
          }
        } catch (e) {
          errorMsg = error?.message || errorMsg;
        }
        console.error('Edge Function error:', errorMsg);
        throw new Error(errorMsg);
      }

      if (!data) {
        throw new Error('No response received from AI service');
      }

      if (data.error) {
        console.error('AI service error:', data.error);
        throw new Error(data.error);
      }

      if (!data.result) {
        throw new Error('AI returned empty response');
      }

      console.log('Raw AI result:', data.result);
      
      // Try to parse the JSON array of questions
      let questionTexts: string[];
      try {
        // First attempt: direct parse
        questionTexts = JSON.parse(data.result);
        
        // Validate it's an array
        if (!Array.isArray(questionTexts)) {
          console.error('Response is not an array:', typeof questionTexts);
          throw new Error('Invalid response format');
        }
        
        // Validate array has string items
        if (questionTexts.some(q => typeof q !== 'string')) {
          console.error('Array contains non-string items');
          throw new Error('Invalid question format');
        }
        
        console.log('Successfully parsed questions:', questionTexts.length);
        
        // Ensure exactly 5 questions
        if (questionTexts.length < 5) {
          console.warn(`Only got ${questionTexts.length} questions, padding to 5`);
          while (questionTexts.length < 5) {
            questionTexts.push(`Tell me about your experience relevant to the ${jobRole} role.`);
          }
        } else if (questionTexts.length > 5) {
          console.warn(`Got ${questionTexts.length} questions, trimming to 5`);
          questionTexts = questionTexts.slice(0, 5);
        }
        
      } catch (parseError) {
        console.error('JSON parse error:', parseError);
        console.error('Failed to parse:', data.result);
        
        // Fallback: try to extract JSON array from text
        const jsonMatch = data.result.match(/\[[\s\S]*\]/);
        if (jsonMatch) {
          try {
            questionTexts = JSON.parse(jsonMatch[0]);
            if (!Array.isArray(questionTexts) || questionTexts.length === 0) {
              throw new Error('Extracted array is invalid');
            }
            console.log('Successfully extracted questions from text');
          } catch (e) {
            console.error('Fallback parse also failed:', e);
            throw new Error('Unable to parse AI response. Please try again.');
          }
        } else {
          console.error('No JSON array found in response');
          throw new Error('AI response format is invalid. Please try again.');
        }
      }
      
      const newQuestions: Question[] = questionTexts.map((text: string, index: number) => ({
        id: index + 1,
        text: text.trim(),
      }));
      
      console.log('Generated questions:', newQuestions);
      setQuestions(newQuestions);
      toast.success('Questions generated successfully!');
      
    } catch (error) {
      console.error('Error generating questions:', error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      toast.error(`Failed to generate questions: ${errorMessage}`);
    } finally {
      setIsGeneratingQuestions(false);
    }
  };

  const handleSubmitAnswer = async () => {
    if (!answer.trim()) {
      toast.error('Please provide an answer before submitting.');
      return;
    }

    try {
      setIsLoading(true);
      const currentQuestion = questions[currentIndex];

      const { data, error } = await supabase.functions.invoke('generate-interview-content', {
        body: {
          action: 'evaluate_answer',
          jobRole,
          question: currentQuestion.text,
          answer: answer.trim(),
          questionIndex: currentIndex + 1,
        },
      });

      if (error) {
        const errorMsg = await error?.context?.text();
        throw new Error(errorMsg || error?.message || 'Failed to evaluate answer');
      }

      if (data?.result) {
        // Parse the evaluation response
        const evaluationText = data.result;
        const evaluation = parseEvaluation(evaluationText);

        // Update question with answer and evaluation
        const updatedQuestions = [...questions];
        updatedQuestions[currentIndex] = {
          ...currentQuestion,
          answer: answer.trim(),
          evaluation,
        };
        setQuestions(updatedQuestions);
        setShowEvaluation(true);
      } else {
        throw new Error('No evaluation received');
      }
    } catch (error) {
      console.error('Error evaluating answer:', error);
      toast.error('Failed to evaluate answer. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const parseEvaluation = (text: string): Evaluation => {
    const feedbackMatch = text.match(/Feedback:\s*(.+?)(?=\nConfidence Score:|$)/s);
    const scoreMatch = text.match(/Confidence Score:\s*(\d+)\/10/);
    const tipMatch = text.match(/Improvement Tip:\s*(.+?)$/s);

    return {
      feedback: feedbackMatch?.[1]?.trim() || 'No feedback provided.',
      confidenceScore: scoreMatch ? parseInt(scoreMatch[1]) : 5,
      improvementTip: tipMatch?.[1]?.trim() || 'Keep practicing!',
    };
  };

  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(currentIndex + 1);
      setAnswer('');
      setShowEvaluation(false);
    } else {
      // Interview complete
      onComplete(questions);
    }
  };

  const handleVoiceTranscription = (text: string) => {
    setAnswer((prev) => (prev ? `${prev} ${text}` : text));
  };

  if (isGeneratingQuestions) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="w-full max-w-2xl glass neon-glow">
          <CardContent className="flex flex-col items-center justify-center py-12 space-y-4">
            <Loader2 className="h-12 w-12 animate-spin text-primary" />
            <p className="text-lg text-muted-foreground">Generating interview questions for {jobRole}...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (questions.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="w-full max-w-2xl glass border-destructive">
          <CardContent className="py-12 text-center space-y-4">
            <p className="text-lg text-destructive">Failed to load questions. Please try again.</p>
            <Button onClick={generateQuestions} variant="outline" className="neon-glow">
              Retry
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const currentQuestion = questions[currentIndex];
  const progress = ((currentIndex + 1) / questions.length) * 100;

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-3xl space-y-6 animate-fade-in">
        {/* Progress Bar */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm text-muted-foreground">
            <span>Question {currentIndex + 1} of {questions.length}</span>
            <span>{Math.round(progress)}% Complete</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Question Card */}
        <Card className="glass neon-glow">
          <CardHeader>
            <CardTitle className="text-2xl text-primary">
              Question {currentIndex + 1}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <p className="text-lg text-foreground leading-relaxed">{currentQuestion.text}</p>

            {!showEvaluation && (
              <>
                <div className="space-y-2">
                  <label htmlFor="answer" className="text-sm font-medium text-foreground">
                    Your Answer
                  </label>
                  <Textarea
                    id="answer"
                    value={answer}
                    onChange={(e) => setAnswer(e.target.value)}
                    placeholder="Type your answer here... (minimum 1000 characters supported)"
                    className="min-h-[200px] glass border-primary/50 focus:border-primary resize-none"
                    disabled={isLoading}
                  />
                  <div className="flex items-center justify-between">
                    <VoiceInput onTranscription={handleVoiceTranscription} disabled={isLoading} />
                    <span className="text-xs text-muted-foreground">{answer.length} characters</span>
                  </div>
                </div>

                <Button
                  onClick={handleSubmitAnswer}
                  disabled={isLoading || !answer.trim()}
                  className="w-full neon-glow"
                  size="lg"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      Evaluating...
                    </>
                  ) : (
                    'Submit Answer'
                  )}
                </Button>
              </>
            )}
          </CardContent>
        </Card>

        {/* Evaluation Display */}
        {showEvaluation && currentQuestion.evaluation && (
          <>
            <EvaluationDisplay evaluation={currentQuestion.evaluation} />
            <Button
              onClick={handleNext}
              className="w-full neon-glow"
              size="lg"
            >
              {currentIndex < questions.length - 1 ? 'Next Question' : 'View Summary'}
            </Button>
          </>
        )}
      </div>
    </div>
  );
};
