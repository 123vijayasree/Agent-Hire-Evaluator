import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

interface WelcomeScreenProps {
  onStart: (jobRole: string) => void;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onStart }) => {
  const [jobRole, setJobRole] = useState('');

  const handleStart = () => {
    if (jobRole.trim()) {
      onStart(jobRole.trim());
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && jobRole.trim()) {
      handleStart();
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl glass neon-glow animate-fade-in">
        <CardHeader className="text-center space-y-4">
          <CardTitle className="text-5xl md:text-6xl font-bold gradient-text">
            Agent Hire Evaluators
          </CardTitle>
          <CardDescription className="text-lg text-muted-foreground">
            AI-Powered Interview Simulation
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <label htmlFor="jobRole" className="text-sm font-medium text-foreground">
              Enter Your Job Role
            </label>
            <Input
              id="jobRole"
              type="text"
              placeholder="e.g., Software Engineer, Product Manager, Data Scientist"
              value={jobRole}
              onChange={(e) => setJobRole(e.target.value)}
              onKeyPress={handleKeyPress}
              className="h-12 text-lg glass border-primary/50 focus:border-primary"
            />
          </div>
          <Button
            onClick={handleStart}
            disabled={!jobRole.trim()}
            className="w-full h-12 text-lg font-semibold neon-glow hover:animate-pulse-glow"
            size="lg"
          >
            Start Interview
          </Button>
          <div className="text-center text-sm text-muted-foreground space-y-1">
            <p>✨ 5 AI-generated questions tailored to your role</p>
            <p>🎤 Text or voice input supported</p>
            <p>📊 Real-time feedback and confidence scores</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
