import React, { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Loader2, Trophy, TrendingUp } from 'lucide-react';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import type { Question, FinalSummary } from '@/types/index';

interface SummaryScreenProps {
  jobRole: string;
  questions: Question[];
  onRestart: () => void;
}

export const SummaryScreen: React.FC<SummaryScreenProps> = ({ jobRole, questions, onRestart }) => {
  const [summary, setSummary] = useState<FinalSummary | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    generateSummary();
  }, []);

  const generateSummary = async () => {
    try {
      setIsLoading(true);
      const allEvaluations = questions.map((q) => ({
        question: q.text,
        answer: q.answer || '',
        feedback: q.evaluation?.feedback || '',
        confidenceScore: q.evaluation?.confidenceScore || 0,
      }));

      const { data, error } = await supabase.functions.invoke('generate-interview-content', {
        body: {
          action: 'generate_summary',
          jobRole,
          allEvaluations,
        },
      });

      if (error) {
        const errorMsg = await error?.context?.text();
        throw new Error(errorMsg || error?.message || 'Failed to generate summary');
      }

      if (data?.result) {
        const summaryText = data.result;
        const parsedSummary = parseSummary(summaryText);
        setSummary(parsedSummary);
      } else {
        throw new Error('No summary received');
      }
    } catch (error) {
      console.error('Error generating summary:', error);
      toast.error('Failed to generate summary. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const parseSummary = (text: string): FinalSummary => {
    const feedbackMatch = text.match(/Overall Feedback:\s*(.+?)(?=\nFinal Confidence Score:|$)/s);
    const scoreMatch = text.match(/Final Confidence Score:\s*(\d+)\/10/);
    const tipMatch = text.match(/Top Improvement Tip:\s*(.+?)$/s);

    return {
      overallFeedback: feedbackMatch?.[1]?.trim() || 'No feedback provided.',
      finalConfidenceScore: scoreMatch ? parseInt(scoreMatch[1]) : 5,
      topImprovementTip: tipMatch?.[1]?.trim() || 'Keep practicing!',
    };
  };

  const getScoreColor = (score: number) => {
    if (score >= 8) return 'bg-primary text-primary-foreground';
    if (score >= 6) return 'bg-secondary text-secondary-foreground';
    return 'bg-destructive text-destructive-foreground';
  };

  const averageScore = questions.reduce((sum, q) => sum + (q.evaluation?.confidenceScore || 0), 0) / questions.length;

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="w-full max-w-3xl glass neon-glow">
          <CardContent className="flex flex-col items-center justify-center py-12 space-y-4">
            <Loader2 className="h-12 w-12 animate-spin text-primary" />
            <p className="text-lg text-muted-foreground">Generating your final summary...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-4xl space-y-6 animate-fade-in">
        {/* Header */}
        <Card className="glass neon-glow border-primary/50">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <Trophy className="h-16 w-16 text-primary animate-pulse-glow" />
            </div>
            <CardTitle className="text-4xl gradient-text">Interview Complete!</CardTitle>
            <p className="text-muted-foreground mt-2">
              Great job completing the {jobRole} interview simulation
            </p>
          </CardHeader>
        </Card>

        {/* Final Summary */}
        {summary && (
          <Card className="glass border-primary/30 animate-slide-up">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="text-2xl text-primary">Final Summary</span>
                <Badge className={`${getScoreColor(summary.finalConfidenceScore)} text-xl px-6 py-2`}>
                  {summary.finalConfidenceScore}/10
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h4 className="font-semibold text-foreground mb-3 flex items-center gap-2">
                  <Trophy className="h-5 w-5 text-primary" />
                  Overall Feedback:
                </h4>
                <p className="text-muted-foreground leading-relaxed text-lg">{summary.overallFeedback}</p>
              </div>
              <div>
                <h4 className="font-semibold text-foreground mb-3 flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-secondary" />
                  Top Improvement Tip:
                </h4>
                <p className="text-muted-foreground leading-relaxed text-lg">{summary.topImprovementTip}</p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Individual Question Scores */}
        <Card className="glass border-primary/30">
          <CardHeader>
            <CardTitle className="text-xl text-foreground">Question Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {questions.map((q, index) => (
                <div key={q.id} className="flex items-center justify-between p-4 rounded-lg glass">
                  <div className="flex-1">
                    <p className="font-medium text-foreground">Question {index + 1}</p>
                    <p className="text-sm text-muted-foreground line-clamp-1">{q.text}</p>
                  </div>
                  <Badge className={getScoreColor(q.evaluation?.confidenceScore || 0)}>
                    {q.evaluation?.confidenceScore || 0}/10
                  </Badge>
                </div>
              ))}
              <div className="flex items-center justify-between p-4 rounded-lg glass border-2 border-primary/50">
                <p className="font-semibold text-foreground text-lg">Average Score</p>
                <Badge className={`${getScoreColor(averageScore)} text-lg px-4 py-1`}>
                  {averageScore.toFixed(1)}/10
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex gap-4">
          <Button
            onClick={onRestart}
            className="flex-1 neon-glow"
            size="lg"
          >
            Start New Interview
          </Button>
        </div>
      </div>
    </div>
  );
};
