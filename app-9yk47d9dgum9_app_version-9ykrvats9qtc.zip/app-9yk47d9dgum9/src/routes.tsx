import InterviewPage from './pages/InterviewPage';
import type { ReactNode } from 'react';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Agent Hire Evaluators',
    path: '/',
    element: <InterviewPage />
  }
];

export default routes;
