import { createClient } from 'jsr:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface RequestBody {
  action: 'generate_questions' | 'evaluate_answer' | 'generate_summary';
  jobRole?: string;
  question?: string;
  answer?: string;
  questionIndex?: number;
  allEvaluations?: Array<{
    question: string;
    answer: string;
    feedback: string;
    confidenceScore: number;
  }>;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const apiKey = Deno.env.get('INTEGRATIONS_API_KEY');
    if (!apiKey) {
      console.error('INTEGRATIONS_API_KEY not found in environment');
      throw new Error('API key configuration error');
    }

    let body: RequestBody;
    try {
      body = await req.json();
    } catch (e) {
      console.error('Failed to parse request body:', e);
      throw new Error('Invalid request format');
    }

    const { action, jobRole, question, answer, questionIndex, allEvaluations } = body;

    if (!action) {
      throw new Error('Action is required');
    }

    if (action === 'generate_questions' && !jobRole) {
      throw new Error('Job role is required for question generation');
    }

    console.log(`Processing ${action} for role: ${jobRole || 'N/A'}`);

    const apiUrl = 'https://app-9yk47d9dgum9-api-VaOwP8E7dJqa.gateway.appmedo.com/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse';

    let prompt = '';
    
    if (action === 'generate_questions') {
      prompt = `You are an AI interview coach. Generate exactly 5 interview questions for a ${jobRole} position. 

Include both technical and behavioral questions relevant to this role.

CRITICAL: Your response must be ONLY a valid JSON array with exactly 5 strings. No markdown, no code blocks, no explanations.

Example format:
["What experience do you have with this technology?", "Describe a challenging project you worked on.", "How do you handle tight deadlines?", "What are your key strengths for this role?", "Where do you see yourself in 5 years?"]

Generate 5 questions now:`;
    } else if (action === 'evaluate_answer') {
      prompt = `You are an AI interview coach evaluating an answer. The candidate is interviewing for a ${jobRole} position.

Question ${questionIndex}: ${question}
Candidate's Answer: ${answer}

Provide your evaluation in EXACTLY this format (no additional text):
Feedback: [Your detailed feedback in 2-3 sentences]
Confidence Score: [X]/10
Improvement Tip: [One specific, actionable tip]`;
    } else if (action === 'generate_summary') {
      const evaluationsSummary = allEvaluations?.map((e, i) => 
        `Q${i + 1}: ${e.question}\nAnswer: ${e.answer}\nFeedback: ${e.feedback}\nScore: ${e.confidenceScore}/10`
      ).join('\n\n');
      
      prompt = `You are an AI interview coach providing a final summary for a ${jobRole} interview.

Here are all the questions and evaluations:
${evaluationsSummary}

Provide your final summary in EXACTLY this format (no additional text):
Overall Feedback: [Comprehensive assessment in 3-4 sentences covering strengths and areas for improvement]
Final Confidence Score: [X]/10
Top Improvement Tip: [The most important recommendation for the candidate]`;
    }

    const requestBody = {
      contents: [
        {
          role: 'user',
          parts: [{ text: prompt }]
        }
      ]
    };

    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Gateway-Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify(requestBody),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('API request failed:', response.status, errorText);
      throw new Error(`API request failed: ${response.status} - ${errorText}`);
    }

    const reader = response.body?.getReader();
    const decoder = new TextDecoder();
    let fullText = '';
    let buffer = '';

    if (reader) {
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split('\n');
          
          // Keep the last incomplete line in the buffer
          buffer = lines.pop() || '';
          
          for (const line of lines) {
            const trimmedLine = line.trim();
            if (trimmedLine.startsWith('data: ')) {
              const dataContent = trimmedLine.slice(6);
              
              // Skip empty data lines
              if (!dataContent || dataContent === '[DONE]') {
                continue;
              }
              
              try {
                const jsonData = JSON.parse(dataContent);
                if (jsonData.candidates?.[0]?.content?.parts?.[0]?.text) {
                  fullText += jsonData.candidates[0].content.parts[0].text;
                }
              } catch (e) {
                console.error('Failed to parse SSE data:', dataContent, e);
              }
            }
          }
        }
        
        // Process any remaining buffer
        if (buffer.trim().startsWith('data: ')) {
          const dataContent = buffer.trim().slice(6);
          if (dataContent && dataContent !== '[DONE]') {
            try {
              const jsonData = JSON.parse(dataContent);
              if (jsonData.candidates?.[0]?.content?.parts?.[0]?.text) {
                fullText += jsonData.candidates[0].content.parts[0].text;
              }
            } catch (e) {
              console.error('Failed to parse final SSE data:', dataContent, e);
            }
          }
        }
      } catch (streamError) {
        console.error('Stream reading error:', streamError);
        throw new Error(`Failed to read AI response stream: ${streamError.message}`);
      }
    }

    if (!fullText) {
      console.error('No text received from AI');
      throw new Error('AI returned empty response');
    }

    // Clean up the response text
    let cleanedText = fullText.trim();
    
    // Remove markdown code blocks if present
    if (cleanedText.startsWith('```json')) {
      cleanedText = cleanedText.replace(/```json\s*/g, '').replace(/```\s*$/g, '');
    } else if (cleanedText.startsWith('```')) {
      cleanedText = cleanedText.replace(/```\s*/g, '');
    }
    
    cleanedText = cleanedText.trim();

    console.log('AI Response (cleaned):', cleanedText);

    return new Response(
      JSON.stringify({ result: cleanedText }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    );

  } catch (error) {
    console.error('Error in generate-interview-content:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    return new Response(
      JSON.stringify({ 
        error: errorMessage,
        details: error instanceof Error ? error.stack : undefined
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    );
  }
});
