const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const apiKey = Deno.env.get('INTEGRATIONS_API_KEY');
    if (!apiKey) {
      throw new Error('INTEGRATIONS_API_KEY not found');
    }

    const formData = await req.formData();
    const audioFile = formData.get('file');

    if (!audioFile) {
      throw new Error('No audio file provided');
    }

    const apiUrl = 'https://app-9yk47d9dgum9-api-DY8MNQoqOnMa.gateway.appmedo.com/v1/audio/transcriptions';

    const transcriptionFormData = new FormData();
    transcriptionFormData.append('file', audioFile);
    transcriptionFormData.append('response_format', 'json');

    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'X-Gateway-Authorization': `Bearer ${apiKey}`,
      },
      body: transcriptionFormData,
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Transcription API failed: ${response.status} - ${errorText}`);
    }

    const result = await response.json();

    return new Response(
      JSON.stringify({ text: result.text || '' }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    );

  } catch (error) {
    console.error('Error in transcribe-audio:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    );
  }
});
